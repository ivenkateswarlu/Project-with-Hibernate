package com.cg.wallet.database;

import java.util.ArrayList;
import java.util.List;

import com.cg.wallet.bean.CustomerBean;

public class DataBase {

	public static void main(String[] args) {
		public static ArrayList<CustomerBean> =new ArrayList<CustomerBean>();
		
	}

}
