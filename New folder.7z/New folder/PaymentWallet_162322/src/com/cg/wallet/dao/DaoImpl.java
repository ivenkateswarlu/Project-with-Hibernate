package com.cg.wallet.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.wallet.bean.CustomerBean;

public class DaoImpl implements IDao {
	List<CustomerBean> customerList=new ArrayList<CustomerBean>();
	@Override
	public boolean createAccount(CustomerBean customerBean) {
		
		customerList.add(customerBean);
		return true;
	}
	@Override
	public boolean depositeAmount(double amount) {
		// TODO Auto-generated method stub
		return false;
	}

}
