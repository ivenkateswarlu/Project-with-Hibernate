package com.cg.wallet.dao;

import com.cg.wallet.bean.CustomerBean;

public interface IDao {

	boolean createAccount(CustomerBean customerBean);

	boolean depositeAmount(double amount);

}
