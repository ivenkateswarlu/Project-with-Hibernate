package com.cg.wallet.exception;

public class ExceptionMessage {

	public static final String ERROR1 = "Enter Valid Last Name";
	public static final String ERROR2 = "Enter valid First Name";
	public static final String ERROR3 = "Enter Address";
	public static final String ERROR4 = "Enter Valid Email Id";
	public static final String ERROR5 = "Enter Valid Phone Number";
	public static final String ERROR6 = null;
	
	

}
