package com.cg.wallet.service;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.bean.DepositeBean;
import com.cg.wallet.dao.DaoImpl;
import com.cg.wallet.dao.IDao;
import com.cg.wallet.exception.AccountDetailsException;
import com.cg.wallet.exception.ExceptionMessage;

public class ServiceImpl implements IService {
	
	IDao dao=new DaoImpl();

	@Override
	public boolean createAccount(CustomerBean customerBean) throws AccountDetailsException {
		boolean result=validate(customerBean);
		boolean isValid=false;
		if(result==true)
			isValid=dao.createAccount(customerBean);
		return isValid;
		
	}

	boolean validate(CustomerBean customerBean) throws AccountDetailsException {
		boolean isValid=true;
		if(!(customerBean.getLastName().matches("[a-zA-Z]{3,}"))){
			isValid=false;
			throw new AccountDetailsException(ExceptionMessage.ERROR1);
		}
		if(!(customerBean.getFirstName().matches("[a-zA-Z]{3,}"))){
			isValid=false;
			throw new AccountDetailsException(ExceptionMessage.ERROR2);
		}
		if(customerBean.getAddress()==null){
			isValid=false;
			throw new AccountDetailsException(ExceptionMessage.ERROR3);
		}
		if(!(customerBean.getEmail().matches("[a-zA-Z][a-zA-z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z)]+)+"))){
			isValid=false;
			throw new AccountDetailsException(ExceptionMessage.ERROR4);
		}
		if(!(customerBean.getPhoneNumber().toString().matches("^[5-9][0-9]{9}"))){
			isValid=false;
			throw new AccountDetailsException(ExceptionMessage.ERROR5);
		}
		return isValid;
		
	}

	@Override
	public boolean depositAmount(double amount) throws AccountDetailsException {
		validateDepositAmount(amount);
		return dao.depositeAmount(amount);
	}

	boolean validateDepositAmount(double amount) throws AccountDetailsException {
		boolean isValid=true;
	if(!(amount<500)){
		isValid=false;
		throw new AccountDetailsException(ExceptionMessage.ERROR6);
	}
		return isValid;
	}
	
	

}
