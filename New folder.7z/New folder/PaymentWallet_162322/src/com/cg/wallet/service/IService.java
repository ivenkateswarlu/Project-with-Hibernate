package com.cg.wallet.service;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.exception.AccountDetailsException;

public interface IService {

public boolean createAccount(CustomerBean customerBean) throws AccountDetailsException;

public boolean depositAmount(double amount) throws AccountDetailsException;

}
