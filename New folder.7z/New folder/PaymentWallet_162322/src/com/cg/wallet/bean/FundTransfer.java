package com.cg.wallet.bean;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalTime;

public class FundTransfer {
	
	
	private LocalDate transferDate;
	private LocalTime transferTime;
	private BigInteger sourceNumber;
	private BigInteger destinationNumber;
	private double transferAmount;
	
	public LocalDate getTransferDate() {
		return transferDate;
	}
	public void setTransferDate(LocalDate transferDate) {
		this.transferDate = transferDate;
	}
	public LocalTime getTransferTime() {
		return transferTime;
	}
	public void setTransferTime(LocalTime transferTime) {
		this.transferTime = transferTime;
	}
	public BigInteger getSourceNumber() {
		return sourceNumber;
	}
	public void setSourceNumber(BigInteger sourceNumber) {
		this.sourceNumber = sourceNumber;
	}
	public BigInteger getDestinationNumber() {
		return destinationNumber;
	}
	public void setDestinationNumber(BigInteger destinationNumber) {
		this.destinationNumber = destinationNumber;
	}
	public double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(double transferAmount) {
		this.transferAmount = transferAmount;
	}
	
}
