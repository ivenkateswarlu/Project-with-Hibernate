package com.cg.wallet.bean;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalTime;

public class DepositeBean {
	
	private LocalDate depositeDate;
	  private LocalTime depositTime;
	  private BigInteger phoneNumber;
	  private double depositeAmount;
	  private double balanceAfterDeposit;
	  
	  
  public LocalDate getDate() {
		return depositeDate;
	}
	public void setDate(LocalDate date) {
		this.depositeDate = date;
	}
	public LocalTime getTime() {
		return depositTime;
	}
	public void setTime(LocalTime time) {
		this.depositTime = time;
	}
	public BigInteger getPhNumber() {
		return phoneNumber;
	}
	public void setPhNumber(BigInteger phNumber) {
		this.phoneNumber = phNumber;
	}
	public double getDepoAmount() {
		return depositeAmount;
	}
	public void setDepoAmount(double depoAmount) {
		this.depositeAmount = depoAmount;
	}
	public double getBalanceAfterDeposit() {
		return balanceAfterDeposit;
	}
	public void setBalanceAfterDeposit(double balanceAfterDeposit) {
		this.balanceAfterDeposit = balanceAfterDeposit;
	}

  
}
