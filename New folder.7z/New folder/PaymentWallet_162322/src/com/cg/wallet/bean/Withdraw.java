package com.cg.wallet.bean;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalTime;

public class Withdraw {
	
	private double balance;
	private LocalDate withDrawDate;
	private LocalTime withDrawTime;
	private BigInteger mobileNumber;
	private double withDrawAmount;
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public LocalDate getWithDrawDate() {
		return withDrawDate;
	}
	public void setWithDrawDate(LocalDate withDrawDate) {
		this.withDrawDate = withDrawDate;
	}
	public LocalTime getWithDrawTime() {
		return withDrawTime;
	}
	public void setWithDrawTime(LocalTime withDrawTime) {
		this.withDrawTime = withDrawTime;
	}
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public double getWithDrawAmount() {
		return withDrawAmount;
	}
	public void setWithDrawAmount(double withDrawAmount) {
		this.withDrawAmount = withDrawAmount;
	}

}
