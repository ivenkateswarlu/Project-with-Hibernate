package com.cg.wallet.ui;

import java.math.BigInteger;
import java.util.Scanner;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.bean.DepositeBean;
import com.cg.wallet.bean.FundTransfer;
import com.cg.wallet.bean.ShowBalance;
import com.cg.wallet.bean.Withdraw;
import com.cg.wallet.exception.AccountDetailsException;
import com.cg.wallet.service.IService;
import com.cg.wallet.service.ServiceImpl;

public class UI {

	public static void main(String[] args) throws AccountDetailsException {
	IService service=new ServiceImpl();
	CustomerBean customerBean=new CustomerBean();
	DepositeBean depositeBean=new DepositeBean();
	FundTransfer fundTransfer=new FundTransfer();
	ShowBalance showBalance=new ShowBalance();
	Withdraw withdraw=new Withdraw();
	Scanner scanner=new Scanner(System.in);
	while(true){
	System.out.println("****Welcome****");
	System.out.println("1.Create Account");
	System.out.println("2.Depoite Amount");
	System.out.println("3.With Draw Amount");
	System.out.println("4.Show Balance");
	System.out.println("5.Fund Transfer");
	System.out.println("6.Print Transcations");
	System.out.println("7.Exit");
	System.out.println("Enter your Choice");
	int option=scanner.nextInt();
	switch (option) {
 case 1:  System.out.println("Enter Your First Name");
			String fname=scanner.next();
			customerBean.setFirstName(fname);
			System.out.println("Enter Your Last Name");
			String lname=scanner.next();
			customerBean.setLastName(lname);
			System.out.println("Enter Your Email Id");
			String email=scanner.next();
			customerBean.setEmail(email);
			System.out.println("Enter Your Address");
			String address=scanner.nextLine();
			customerBean.setAddress(address);
			System.out.println("Enter Mobile Number");
			BigInteger number=scanner.nextBigInteger();
			customerBean.setPhoneNumber(number);
			if(service.createAccount(customerBean))
			{
				System.out.println("account is Created :-)");
			}
			else
			{
				System.out.println("Not Created :-(");
			}
		
		break;
 case 2:
	 System.out.println("Enter amount to deposit");
	 double amount=scanner.nextDouble();
	 depositeBean.setDepoAmount(amount);
	 if(service.depositAmount(amount)){
		 
	 }
	 break;
	default:
		break;
	}
	
	
	}

	}

}
